import re
from typing import Any

from backend.app.services.quickbooks_service import QuickBooksService

# Sample data for the mock QBO sandbox.
_CUSTOMERS: list[dict[str, Any]] = [
    {
        "Id": "100",
        "DisplayName": "John Smith",
        "PrimaryEmailAddr": {"Address": "john@example.com"},
        "PrimaryPhone": {"FreeFormNumber": "555-0100"},
        "Balance": 0,
    },
    {
        "Id": "101",
        "DisplayName": "Jane Doe",
        "PrimaryEmailAddr": {"Address": "jane@example.com"},
        "PrimaryPhone": {"FreeFormNumber": "555-0101"},
        "Balance": 250.00,
    },
]

_INVOICES: list[dict[str, Any]] = [
    {
        "Id": "1001",
        "DocNumber": "INV-1001",
        "CustomerRef": {"value": "100", "name": "John Smith"},
        "TotalAmt": 500.00,
        "Balance": 0,
        "DueDate": "2026-02-15",
        "TxnDate": "2026-01-15",
        "EmailStatus": "EmailSent",
        "Line": [
            {
                "Amount": 350.00,
                "Description": "Pipe repair labor",
                "DetailType": "SalesItemLineDetail",
                "SalesItemLineDetail": {"Qty": 7, "UnitPrice": 50.0},
            },
            {
                "Amount": 150.00,
                "Description": "Copper fittings",
                "DetailType": "SalesItemLineDetail",
                "SalesItemLineDetail": {"Qty": 10, "UnitPrice": 15.0},
            },
        ],
    },
    {
        "Id": "1002",
        "DocNumber": "INV-1002",
        "CustomerRef": {"value": "101", "name": "Jane Doe"},
        "TotalAmt": 1250.00,
        "Balance": 250.00,
        "DueDate": "2026-03-01",
        "TxnDate": "2026-02-01",
        "EmailStatus": "NotSet",
        "Line": [
            {
                "Amount": 800.00,
                "Description": "Kitchen remodel labor",
                "DetailType": "SalesItemLineDetail",
                "SalesItemLineDetail": {"Qty": 16, "UnitPrice": 50.0},
            },
            {
                "Amount": 450.00,
                "Description": "Cabinet materials",
                "DetailType": "SalesItemLineDetail",
                "SalesItemLineDetail": {"Qty": 3, "UnitPrice": 150.0},
            },
        ],
    },
]

_ESTIMATES: list[dict[str, Any]] = [
    {
        "Id": "2001",
        "SyncToken": "0",
        "DocNumber": "EST-2001",
        "CustomerRef": {"value": "100", "name": "John Smith"},
        "TotalAmt": 3200.00,
        "TxnDate": "2026-01-10",
        "ExpirationDate": "2026-02-10",
        "TxnStatus": "Accepted",
    },
]

_ITEMS: list[dict[str, Any]] = [
    {
        "Id": "1",
        "Name": "Drywall Sheet 4x8",
        "Description": "Standard 1/2 inch drywall sheet",
        "UnitPrice": 12.50,
        "Type": "Inventory",
    },
]

_ENTITY_DATA: dict[str, list[dict[str, Any]]] = {
    "Customer": _CUSTOMERS,
    "Invoice": _INVOICES,
    "Estimate": _ESTIMATES,
    "Item": _ITEMS,
}


class MockQuickBooksService(QuickBooksService):
    """In-memory mock QuickBooks service for testing.

    Supports a subset of QBO query syntax: entity routing, WHERE with simple
    conditions (=, LIKE), and MAXRESULTS.
    """

    async def query(self, query_str: str) -> list[dict[str, Any]]:
        # Parse entity name from "SELECT ... FROM <Entity> ..."
        match = re.search(r"FROM\s+(\w+)", query_str, re.IGNORECASE)
        if not match:
            return []
        entity = match.group(1)
        rows = list(_ENTITY_DATA.get(entity, []))

        # Simple WHERE field = 'value' filter
        eq_match = re.search(r"WHERE\s+(\w+)\s*=\s*'([^']*)'", query_str, re.IGNORECASE)
        if eq_match:
            field, value = eq_match.group(1), eq_match.group(2)
            rows = [r for r in rows if str(r.get(field, "")) == value]

        # Simple WHERE field LIKE '%value%' filter
        like_match = re.search(r"WHERE\s+(\w+)\s+LIKE\s+'%([^%]*)%'", query_str, re.IGNORECASE)
        if like_match:
            field, value = like_match.group(1), like_match.group(2)
            rows = [r for r in rows if value.lower() in str(r.get(field, "")).lower()]

        # MAXRESULTS
        max_match = re.search(r"MAXRESULTS\s+(\d+)", query_str, re.IGNORECASE)
        if max_match:
            rows = rows[: int(max_match.group(1))]

        return rows

    async def create_entity(self, entity_type: str, data: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError("MockQuickBooksService.create_entity not implemented")

    async def update_entity(self, entity_type: str, data: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError("MockQuickBooksService.update_entity not implemented")

    async def send_entity_email(
        self, entity_type: str, entity_id: str, email: str
    ) -> dict[str, Any]:
        raise NotImplementedError("MockQuickBooksService.send_entity_email not implemented")
